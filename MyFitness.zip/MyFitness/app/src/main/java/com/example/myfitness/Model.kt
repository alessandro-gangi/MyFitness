package com.example.myfitness

class Model {

    //Model class for connecting to server


    fun perform_registration(mail:String, usr:String, pwd:String){
        //perform registartion
    }

    fun perform_login(usr:String, pwd:String){
        //perform login
    }
}
